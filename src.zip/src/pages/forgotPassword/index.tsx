import { AuthPage } from "@refinedev/mui";

export const ForgotPassword = () => {
  return <AuthPage type="forgotPassword" />;
};
